
const hearts = [];
document.addEventListener('mousemove', (e) => {
    const heart = document.createElement('div');
    heart.textContent = '💗';
    heart.style.position = 'absolute';
    heart.style.left = `${e.clientX}px`;
    heart.style.top = `${e.clientY}px`;
    heart.style.pointerEvents = 'none';
    heart.style.fontSize = '20px';
    heart.style.zIndex = 9999;
    document.body.appendChild(heart);
    hearts.push(heart);

    setTimeout(() => {
        heart.remove();
    }, 1000);
});
